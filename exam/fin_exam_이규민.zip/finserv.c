//소켓 통신에 필요한 헤더파일들이다.
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/select.h>

#define SERV_TCP_PORT 31289		//여러 프로그램 중 프로그램 구별을 위해 포트 설정을 한다.
#define SERV_ADDR "192.168.0.5"	//IP 주소를 입력 시 서버 컴퓨터의 주소를 입력한다

struct client{
	char name[20];
	int partners[10]; // socket number of partners. max 10 chatting partners are allowed
   	int numPartners; // number of partners of this client
   	int numPartnersSoFar; // initially 0. increased by one each time the server receives
	// the next chat partner name
};

void handle_protocol(int x, fd_set * pset, int state[], struct client cli[]);
void chat_protocol(int x, int s1, fd_set * pset, int state[], struct client cli[]);

int main(){
   int s1,s2, i, x, y;
   struct sockaddr_in serv_addr, cli_addr;
   char buf[50];
   socklen_t  xx;

   printf("Hi, I am the server\n");
   
   bzero((char *)&serv_addr, sizeof(serv_addr));
   serv_addr.sin_family=PF_INET;
   serv_addr.sin_addr.s_addr=inet_addr(SERV_ADDR);
   serv_addr.sin_port=htons(SERV_TCP_PORT);

   //open a tcp socket
   if ((s1=socket(PF_INET, SOCK_STREAM, 0))<0){
      printf("socket creation error\n");
      exit(1);
   }
   printf("socket opened successfully. socket num is %d\n", s1);

   //어떤 클라이언트에게 올지 모르므로 자신을 바인딩한다. 
   x =bind(s1, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
   if (x < 0){
      printf("binding failed\n");
      exit(1);
   }
   printf("binding passed\n");
   listen(s1, 5);
   xx = sizeof(cli_addr);

   // now start ping-pong-pang-pung
   // pset remembers all sockets to monitor
   // rset is the copy of pset passed to select
   fd_set rset, pset;

   int maxfd = 50;

   FD_ZERO(&rset); // init rset
   FD_ZERO(&pset); // init pset

   // step 1. s1 is a socket to accept new connection request. 
   // monitor connection request packet at s1
   FD_SET(s1, &pset);
   
   int state[50];
   struct client cli[50];

   // and loop on select
   for(;;){ 
      rset = pset;  // step 2
      select(maxfd, &rset, NULL, NULL, NULL); // step 3
      // now we have some packets
      for(x=0; x<maxfd; x++){ // check which socket has a packet
         if (FD_ISSET(x, &rset)){ // socket x has a packet
            // s1 is a special socket for which we have to do "accept"            
            if (x == s1){ // new client has arrived
               	//클라이언트 연결 요청을 기다린다.
				//이 경우는 부모 프로세스만 이 작업을 한다.
               	s2 = accept(s1, (struct sockaddr *)&cli_addr, &xx);
               	printf("new cli at socket %d\n",s2);
               	FD_SET(s2, &pset); //클라이언트 연결이 된 경우 이를 pset에서 해당 프로세스
								   //디스크립터를 1로 바꿔둔다.
				state[s2] = 1;	   //state 초기 설정은 1로한다.
				cli[s2].numPartnersSoFar = 0;
            }else{ //자식 프로세스만이 프로토콜을 실행한다.
				if(state[x] > 0 && state[x] < 6)
           			handle_protocol(x, &pset, state, cli);

				else
					chat_protocol(x, s1, &pset, state, cli);
            }
         }
      }
   }
}

void handle_protocol(int x, fd_set * pset, int state[], struct client cli[]){
   // we have a data packet in socket x. do protocol.
   int y; char buf[50];
   y = read(x, buf, 50);  // read data from socket x
   buf[y] = 0;         // make it a string
   printf("we have received %s at socket %d\n", buf, x);

   //ping을 입력 받으면 답변을한다.
   if (state[x] == 1 && strcmp(buf, "ping") == 0){
      write(x, "pong", 4);
      printf("we have sent pong to socket %d\n", x);
   	  state[x]++;
   }

   //pang을 입력받으면 이름을 묻는다.
   else if (state[x] == 2 && strcmp(buf, "pang") == 0){
      write(x, "name?", 5);
      printf("we have sent name? to socket %d\n", x);
   	  state[x]++;
   }

   //이름을 구조체 name에 저장하고, 원하는 파트너 수를 요청한다.
   else if (state[x] == 3){
   	  strcpy(cli[x].name, buf);
      write(x, "how many chat partners?", 23);
   	  state[x]++;
   }

   //파트너 수를 구조체에 저장하고, 파트너 이름을 묻는다.
   else if(state[x] == 4){
   	  cli[x].numPartners = atoi(buf);
      write(x, "chat partner 1?", 15);
   	  state[x]++;
   }

   //파트너 이름을 구조체에 저장한다.
   else if(state[x] == 5){
   	  //모든 구조체의 name을 확인한다.
   	  for(int i = 0; i < 50; i++)
      {
          if(strcmp(buf, cli[i].name) == 0)
          {
		  	  //일치하는 이름이 있다면 구조체에 저장한다.
              //이 경우 numPartnersSoFar은 몇 번째 파트너인지 의미한다.
              cli[x].partners[cli[x].numPartnersSoFar] = i;
			  cli[x].numPartnersSoFar++;
              break;
          }
      }

	  //이전에 입력됐던 파트너 수만큼 파트너를 찾았다면 채팅을 시작한다.
	  if(cli[x].numPartnersSoFar >= cli[x].numPartners)
	  {
	  	  state[x]++;
		  write(x, "start chatting", 14);
	  }

	  //아직 파트너를 모두 찾지 않았다면 그 다음 파트너 이름을 요청한다.
	  else
	  {
      	  sprintf(buf, "chat partner %d?", cli[x].numPartnersSoFar + 1);
      	  write(x, buf, strlen(buf));
	  }
   }

   //만약 위 내용 진행 중 다른 내용이 입력된다면 통신을 끊는다.
   else{
      printf("protocol error. disconnecting socket %d\n", x);
      write(x, "protocol error", 14);
	  state[x] = 0;
      close(x);
      FD_CLR(x, pset);
   }
}

void chat_protocol(int x, int s1, fd_set * pset, int state[], struct client cli[]){
	int y; char buf[50];
	y = read(x, buf, 50);	//입력받은 내용을 buf에 저장한다.
	buf[y] = '\0';

	char message[50];

	//모든 파트너에게 client가 입력한 메시지를 전송한다.
	for(int i = 0; i < cli[x].numPartners; i++)
	{
		sprintf(message, "%s to %s : %s", cli[x].name, cli[cli[x].partners[i]].name, buf);
		write(cli[x].partners[i], message, strlen(message));
	}
}

